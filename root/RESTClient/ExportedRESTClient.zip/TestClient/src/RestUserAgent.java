/**
 * the REST version of CLIUserAgent
 * handles interactions with the user (input, output) via command-line interface
 * All operations are designed to be like that of CLIUserAgent
 *
 * contains: RestClient
 * maintains an object of RestClient to delegate the handling of REST protocol
 * 
 * extends: Thread
 * maintains a separate thread dedicated to poll new messages from the server 
 */
import java.util.Scanner;

public class RestUserAgent extends Thread {
	//** instance variables **\\
	// the msgclient to take care of message protocols
	private RestClient restCLient;

	
	/**
	 * constructor
	 * 
	 * @param user 			The name of the user
	 * @param server		The host name of the server
	 * @param port 			The 
	 **/ 
	@SuppressWarnings("all")
	public RestUserAgent () throws Exception
	{
		ServerResponse svrp = null;
		int statusCode = 0;
		
		// start a thread to get new messages every two seconds
		//this.start();
		
		

		// initializes a Scanner to read user's terminal input
		Scanner input = new Scanner( System.in );
		
		// The command read from user's input
		String command = "";
		
		// The array of splitted parts of the command
		String[] commandParts = null; 

		// The reply code received as a response of requests
		int replyCode = 0;

		
		System.out.print("Please type in username:");
		String user = input.nextLine();
		
		// creates a socket connecting with server at the specified port
		// initializes a new RestClient instance to handle REST requests
		restCLient = new RestClient( user );  
		
		System.out.print("Please type in your password:");
		String password = input.nextLine();
		
		
		svrp = restCLient.login(password);
		// The infinite loop to read and process user's inputs and display corresponding results
		
		while ( svrp.getStatusCode() != 200)
		{
			System.out.println("Error: "+svrp.getResponseBody());
			System.out.print("Re-enter username:");
			restCLient.setUserName(input.nextLine());
			System.out.print("Re-enter password:");
			svrp = restCLient.login(input.nextLine());
		}

		System.out.println("Logged in successfully. access_token: "+svrp.getResponseBody());
			
		
		while(true)
		{
			System.out.println("\nPlease select action by entering..."
					+ "\n1 to log out"
					+ "\n2 to create new user (admin only)"
					+ "\n3 to create new organization (admin only)"
					+ "\n4 to associate an organization with a user (admin only)");
			
			int choice = input.nextInt();
			if ( choice == 1)
			{
				svrp = restCLient.logout();
				
				if (svrp.getStatusCode() == 200)
					System.out.println("Logged out successfully");
				else
					System.out.println("Error: "+svrp.getResponseBody());
				System.exit(0);
			}
			else if ( choice == 2)
			{
				System.out.print("please enter user id and password of the user to be created:");
				input.nextLine();
				String uName = input.nextLine();
				String pWord = input.nextLine();
				System.out.print("would you like to grant this user administratior privileges? 1 for yes, 0 for no:");
				int isAd = input.nextInt(); 
				svrp = restCLient.createNewUser(uName,pWord,isAd);
				
				if (svrp.getStatusCode() == 200)
					System.out.println(svrp.getResponseBody());
				else
					System.out.println("Error: "+svrp.getResponseBody());
			}
			else if ( choice == 3)
			{
				System.out.print("please enter org_id and org_name for the organization to be created:");
				input.nextLine();
				String org_id = input.nextLine();
				String org_name = input.nextLine();
				
				svrp = restCLient.createNewOrg(org_id,org_name);
				
				if (svrp.getStatusCode() == 200)
					System.out.println(svrp.getResponseBody());
				else
					System.out.println("Error: "+svrp.getResponseBody());
			}
			else if ( choice == 4)
			{
				System.out.print("please enter the ids of the organization and the user to be associated:");
				input.nextLine();
				String org_id = input.nextLine();
				String usr_id = input.nextLine();
				
				svrp = restCLient.assocOrgWithUser(org_id,usr_id);
				
				if (svrp.getStatusCode() == 200)
					System.out.println(svrp.getResponseBody());
				else
					System.out.println("Error: "+svrp.getResponseBody());
			}
			
			
		}
		
		
	}


	// the main method
	public static void main( String args[]) throws Exception
	{
		// checks the number of terminal arguments
		/*if (args.length < 1 || args.length > 4)
		{
			System.out.println("Wrong number of arguments!!!");
			System.exit(0);
		}*/
		
		/*System.out.println("Welcome to REST User Agent Interface !!!"
				+ "\nHere's the list of supported commands:"
				+ "\njoin <group>	: join a group"
				+ "\nleave <group>	: leave a group"
				+ "\ngroups		: get the list of groups"
				+ "\nusers		: get the list of all users"
				+ "\nusers <group>	: get the list of users in a group"
				+ "\nhistory <group> : history of a group's messages"
				+ "\nhistory @<user> : history of a user's messages"
				+ "\nsend (#<group>||@<user> ) message : send a message to listed recipients."
				+ "\nPlease enter commands following these systax. Thank you. :)\n");*/
		
		
		// initializes a new CLIUserAgent object
		new RestUserAgent();
	}// end of main method

	
	
	/** 
     * the message-listenner thread run this method
     * polls the server every two seconds to get new message on behalf of the user
     **/
	/*public void run()
	{
		while( true )
		{
			try
			{
				Thread.sleep(2000);
			}
			catch( InterruptedException ie)
			{
				ie.printStackTrace();
			}
			ArrayList<MsgpMessage> messages = (ArrayList<MsgpMessage>) restCLient.getNewMessages();
			
			this.printMessages(messages);
		}	
	} // end of run method*/
	


	/*// helper method to split the send command into the recipient list and the message
	private void extractSendCommand(String command)
	{
		// clear the recipient list that persists from previous call
		recipients.clear();
		
		// the string array to hold the splitted substrings
		// initially split the command in two to discard the String "send" 
		String subStrings[] = command.split(" ",2);
		
		do 
		{
			// split the second subString in two
			subStrings = subStrings[1].split(" ",2);

			// the first subString should be a recipient, add it to the list
			recipients.add( subStrings[0] );
		}
		// continue until there is more recipient to extract
		while( subStrings[1].startsWith("@") || subStrings[1].startsWith("#") );

		// the subString that doesn't start with '@' or '#' is the message
		messageOut = subStrings[1];
		
	}// end of method extractSendCommand*/


	
}
